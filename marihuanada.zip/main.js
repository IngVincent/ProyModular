console.log('Inicio');

setTimeout (function()
{
    console.log('Primer TimeOut');
},3000);